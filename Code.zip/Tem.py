# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 23:30:55 2022
@author: Y.WONG
"""

import tensorflow as tf
import keras
import keras.backend as K
import keras.layers as KL

def Tem(input_feature):
    
    max = KL.MaxPooling2D((2, 2), strides = (2, 2))(input_feature)
    ave = KL.AveragePooling2D((2, 2), strides = (2, 2))(input_feature)
    
    tm = KL.Subtract()([max, ave])
    
    return KL.Add()([tm, max])