# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 23:30:55 2022
@author: Y.WONG
"""

import numpy as np
import tensorflow as tf
import keras
import keras.backend as K
import keras.layers as KL


def Tcam(input_feature):
    
    c_max = KL.MaxPooling2D((2, 2), strides = (2, 2))(input_feature)
    c_ave = KL.AveragePooling2D((2, 2), strides = (2, 2))(input_feature)
    
    c_tm = KL.Subtract()([c_max, c_ave])
    
    c_tam = KL.GlobalAveragePooling2D()(c_tm)
    
    c_tam = KL.Activation('sigmoid')(c_tam)
    
    return KL.Multiply()([c_tam, input_feature])

def Tsam(c_tam):
    
    #s_max = KL.Lambda(lambda x: K.max(x, axis = 3, keepdims = True))(c_tam)
    #s_ave = KL.Lambda(lambda x: K.mean(x, axis = 3, keepdims = True))(c_tam)
    
    s_max = KL.MaxPooling2D((2, 2), strides = (2, 2))(c_tam)
    s_ave = KL.AveragePooling2D((2, 2), strides = (2, 2))(c_tam)
    
    s_tm = KL.Subtract()([s_max, s_ave])
    
    return KL.Conv2D(filters = 1, kernel_size = (3, 3), padding = "same", activation = 'sigmoid', kernel_initializer = 'he_normal', use_bias = False)(UpSampling2D(size = (2, 2))(s_tm))

def Tam(input_feature):
    
    c_tam = Tcam(input_feature)
    
    s_tam = Tsam(c_tam)
    
    s_tam = KL.Multiply()([s_tam, c_tam])
    
    return KL.Add()([s_tam, input_feature])